## ---- Actividad 9 ----##
# generamos la agenda:
agenda = {
    ("Lunes", "08:00"): "Capacitacion",
    ("Martes", "10:20"): "Reunion",
    ("Miercoles", "14:30"): "Yoga",
    ("Jueves", "07:00"): "Clases",
    ("Viernes", "22:00"): "Pizza con amigos",
    ("Sabado", "19:45"): "Reunion",
    ("Domingo", "20:30"): "asado en casa"
}
print("bienvenido a la agenda: ")
while True:
    # reiniciamos la variable para analizarla
    # en caso de que no se encuentre ninguna actividad:
    reserva_dia = "\nno tenes ninguna actividad."
    # solicitamos el dia a buscar en la agenda:
    dia = input("""\n
    ingresa el dia o la hora
    para ver que actividad tienes pendiente:
        ingresa el dia: """).replace(" ", "").title()
    # validamos el ingreso buscando dentro de las tuplas:
    while dia not in [i[0] for i in list(agenda.keys())]:
        dia = input("debes ingresar un dia de la semana: ").replace(
            " ", "").title()
    # solicitamos la hora:
    hora = input("\n    ingresa la hora: ").replace(" ", "")
    # verificamos que los datos dentro de hora sean numeros:
    val_hora = hora.replace(":", "")
    # en caso de que no sean numeros o sean valores que no
    # representan de forma correcta la hora:
    while val_hora.isdigit() == False or len(val_hora) > 4 and ":" != hora[2] or ":" not in hora:
        hora = input(
            "\n\nerror: debes ingresar el horario de esta forma: 00:00\n   ingresa el horario: ").replace("", "")
        val_hora = hora.replace(":", "")
    # recorremos la agenda buscando el dia y la hora:
    for (d, h), x in agenda.items():
        # en caso de que se encuentre el dia y la hora ingresado:
        if dia == d and hora == h:
            reserva_dia = f"\nel dia {d} a las {h} tenes esta actividad: {x}"
    # imprimimos el resultado de la busqueda:
    print(reserva_dia)
