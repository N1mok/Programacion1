## ---- Actividad 6 ----##
# esta funcion se encargara de validar las notas y volverlas un numero entero:
def validar_num(num):
    while num.isdigit() == False:
        num = input("Error: solo puedes ingresar numeros\n nota: ")
    num = int(num)
    return num


# este diccionario contendra los nombres de los alumnos y una tupla con sus notas:
alumnos = {}
# imprimimos informacion para que el operador entienda lo que se espera:
print("""
    a continuacion ingresa el nombre de tres (3)
    alumnos seguido de tres (3) de sus notas:
    """)
# solicitamos al operador que ingrese los nombres y las notas mediante el bucle for:
for i in range(3):
    # se solicita el ingreso del nombre:
    nom_Alumno = input(f"ingresa el nombre del alumno {i+1}: ").replace(
        " ", "").title()
    # validamos el ingreso:
    while nom_Alumno.isalpha() == False:
        nom_Alumno = input(
            "Error: solo puedes ingresar letras\n  Nombre alumno: ").replace(" ", "").title()
    # solicitamos las notas:
    a = input("ingresa la primera nota: ")
    # validamos con la funcion validar_num:
    a = validar_num(a)
    b = input("ingresa la segunda nota: ")
    b = validar_num(b)
    c = input("ingresa la tercer nota: ")
    c = validar_num(c)
    # una vez que todo esta correcto se guarda la informacion en el diccionario alumnos:
    alumnos[nom_Alumno] = (a, b, c)
# creamos una lista para obtener la suma de las notas de cada alumno:
promedio = []
# realizamos la suma con un contador que se reinicia por cada alumno dentro de la lista:
for i, x in alumnos.items():
    # contador:
    suma = 0
    # ingresamos a la tupla:
    for z in x:
        # realizamos la suma:
        suma += z
    # una vez obtenida la suma, dividimos el resultado
    # por la cantidad de notas para obtener
    # el promedio de cada alumno:
    suma /= 3
    # guardamos el resultado en la lista:
    promedio.append(suma)
# recorremos el diccionario y la lista utilizando la funcion zip
# para imprimir todo en pantalla:
for (i, x), z in zip(alumnos.items(), promedio):
    print(f"Alumno: {i} - notas: ", end=" ")
    for j in x:
        print(j, end=" ")
    print(f"- promedio: {z}\n")
