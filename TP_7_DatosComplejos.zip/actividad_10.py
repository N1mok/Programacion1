## ---- Actividad 10 ----##
# esta funcion recorre las listas para imprimirlas:
def listas(implista):
    for i, x in implista.items():
        print(f"{i} : {x}")


# creamos el diccionario que contiene los paises y sus capitales:
lista_original = {
    "Argentina": "Buenos Aires",
    "Chile": "Santiago",
    "Brasil": "brasilia",
    "Uruguay": "Montevideo",
    "Paraguay": "Asuncion",
    "Bolivia": "Sucre"
}
# creamos un diccionario vacio que contendra los valores invertidos:
lista_invertida = {}
# utilizando un bucle for recorremos el diccionario original:
for i, x in lista_original.items():
    # guardamos en el diccionario vacio los valores invertidos:
    lista_invertida[x] = i
# imprimimos el diccionario original:
print("lista original: ")
listas(lista_original)
# imprimimos el diccionario invertido:
print("\nlista invertida: ")
listas(lista_invertida)
