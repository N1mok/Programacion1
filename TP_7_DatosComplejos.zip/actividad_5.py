## ---- Actividad 5 ----##
# informamos lo que realizara el programa al operador:
print("""
a continuacion vamos a solicitarte que ingreses una frase
para analizarla, vamos a contar cada palabra para ver cuantas
veces se repite, te mostraremos las palabras unicas
y la cantidad de veces que se repiten""")
# se solicita la frase al operador:
frase = input("ingresa una frase: ").replace(",", " ").replace(".", " ")
# separamos cada palabra para crear una lista:
palabras = frase.split()
# utilizamos set para obtener las palabras unicas:
set_palabras = set(palabras)
# creamos un diccionario que almacenara cada palabra y la cantidad de veces que aparece:
diccionario_palabras = {}
# recorremos la frase para obtener lo solicitado:
for i in palabras:
    # la variable cantidad guarda las veces que se repite la palabra:
    cantidad = palabras.count(i)
    # al guardar dentro del diccionario
    # la variable i define la clave
    # y la variable cantidad el valor :
    diccionario_palabras[i] = cantidad
# una vez obtenidos los resultados:
# imprimimos las palabras que se encuentran dentro de la frase sin repetir:
print("\nlista de palabras dentro de la frase: ")
for i in set_palabras:
    if i == list(set_palabras)[-1]:
        print(i, end=" ")
    else:
        print(i, end=", ")
# recorremos el diccionario, imprimimos la clave(i) y el valor(x):
print("\n\nCantidad de veces que se repiten las palabras dentro de la frase: ")
for i, x in diccionario_palabras.items():
    if i == list(diccionario_palabras)[-1]:
        print(f"{i}:{x}", end="")
    else:
        print(f"{i}:{x}", end=", ")
