## ---- Actividad 1 ----##
# creamos el diccionario como fue solicitado:
precios_frutas = {
    'Banana': 1200,
    'Ananá': 2500,
    'Melón': 3000,
    'Uva': 1450
}
print("diccionario original:\n")
# imprimimos el diccionario original
print("frutas:")
for key, value in precios_frutas.items():
    print(f" {key} - precio:{value}")
#
#
## ---- Actividad 2 ---- ##
# actualizamos el diccionario con los datos nuevos:
precios_frutas.update({'Naranja': 1200, 'Manzana': 1500, 'Melón': 2800})
print("\ndiccionario actualizado: \n")
# imprimimos el diccionario actualizado:
print("frutas:")
for key, value in precios_frutas.items():
    print(f" {key} - precio:{value}")
#
#
## ---- Actividad 3 ---- ##
# creamos una lista con las claves dentro del diccionario:
lista_frutas = list(precios_frutas.keys())
print(f"\nlista con los nombres de las frutas en el diccionario:\n")
# imprimimos la lista:
for i in range(len(lista_frutas)):
    if lista_frutas[i] == lista_frutas[-1]:
        print(lista_frutas[i], end="")
    else:
        print(lista_frutas[i], end=", ")
