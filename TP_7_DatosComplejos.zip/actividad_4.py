## ---- Actividad 4 ----##
print("bienvenido a la agenda")
# el diccionario contendra los nombres como clave y los numeros como valor:
agenda = {}
print("\na continuacion te pediremos 5 nombres y sus numeros para agregarlos a la agenda\n")
# utilizando el bucle for se le solicitaran 5 nombres con sus correspondientes numeros al usuario:
for i in range(5):
    # primero se le solicitara el nombre:
    nombre = input("  nombre a agendar: ").replace(" ", "").title()
    # validamos que ingrese nombres propios sin caracteres especiales o numeros:
    while nombre.isalpha() == False:
        nombre = input(
            "Error: no puedes ingresar numeros o caracteres especiales.\n     nombre: ").replace(" ", "").title()
    # una vez validado el nombre solicitamos el numero:
    numero = input(f"ingresa el numero de {nombre}: ").replace(" ", "")
    # validamos que el dato ingresado solo contenga numeros:
    while numero.isdigit() == False:
        numero = input(
            f"Error: solo puedes ingresar numeros.\ningresa el numero de {nombre}: ").replace(" ", "")
    # guardamos el nombre y el numero dentro del diccionario:
    agenda[nombre] = numero
# ahora permitimos al usuario buscar los nombres que ingreso a la agenda:
# el bucle se mantendra activo hasta que el usuario ingrese la palabra salir #
while True:
    print("""
    ingresa un nombre para buscar en la agenda
    o ingresa salir para finalizar el programa: """)
    busqueda = input("    nombre: ").replace(" ", "").title()
    # el .get en caso de que no se encuentre el nombre devuelve
    # un valor que determinamos para que no sea none:
    print(
        f"           {busqueda}: {agenda.get(busqueda, 'no se encontro en la agenda.')}")
    # condicion para salir del bucle:
    if busqueda == "Salir":
        break
