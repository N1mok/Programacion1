## ---- Actividad 7 ----##
# se establecen las asistencias a la capacitacion:
asistencias = ["ana", "daniel", "fabian",
               "ana", "maria", "julian", "daniel", "ana", "maria"]
# limpiamos los repetidos utilizando la funcion set
empleado = set(asistencias)
# creamos un diccionario para indicar cuantas asistencias tubo cada empleado
Presentismo = {}
# recorremos la lista para ir contando asistencias:
for i in asistencias:
    # la funcion .count() devuelve la cantidad de veces que se repite cada nombre
    # el resultado se guarda en la variable cantidad_asistencias:
    cantidad_asistencias = asistencias.count(i)
    # guardamos el nombre del empleado como key y la cantidad de asistencias como value:
    Presentismo[i] = cantidad_asistencias
# imprimimos cada una de las listas:
# lista original:
print("lista completa de asistencias:")
for i in asistencias:
    print(i, end=" ")
# lista sin nombres repetidos:
print("\n\nlista de empleados:")
for i in empleado:
    if i == list(empleado)[-1]:
        print(i, end="")
    else:
        print(i, end=", ")
print("\n\nasistencias totales por empleado a la capacitacion:")
# recorremos el diccionario y desempaquetamos sus datos:
# i es la clave y x es el valor del diccionario
for i, x in Presentismo.items():
    if i == list(Presentismo)[-1]:
        print(f"{i} :{x}", end="")
    else:
        print(f"{i} :{x}", end=", ")
