## ---- Actividad 8 ----##
# creamos un diccionario para almacenar los items con valores iniciales:
# Importante: todos las claves se estandarizan con un .title() y .replace() para evitar errores:
stock = {"Fideos": 10, "Aceite": 4, "Arroz": 3, "Harina": 8}
# dentro del bucle corremos el menu con las opciones:
while True:
    print("""
        menu control de stock:
        1.- consultar stock de articulos.
        2.- actualizar stock.
        3.- agregar articulo.
    """)
    # se solicita al usuario que ingrese la opcion:
    select = input("    opcion: ").replace(" ", "")
    # validamos la opcion:
    while select.isdigit() == False:
        print("""
                            Error: 
                solo puedes ingresar una de las 
                  opciones antes mencionadas.
                """)
        select = input("""
        menu control de stock:
        1.- consultar stock de articulos.
        2.- actualizar stock.
        3.- agregar articulo.
            
            opcion: """).title().replace(" ", "")
    # en caso de que el usuario ingrese la opcion 1:
    if select == "1":
        print(" \ningresaste a: consulta de articulos y stock")
        # se solicita el item a buscar dentro del inventario:
        busqueda = input(
            "ingresa el producto que estas buscando: ").title().replace(" ", "")
        # validamos el ingreso del usuario:
        while busqueda.isalnum() == False:
            busqueda = input(
                "error: no puedes ingresar caracteres especiales.").title().replace(" ", "")
        # si lo que busca se encuentra:
        if busqueda in stock:
            print(f"{busqueda}:{stock[busqueda]}")
        # caso contrario, no se encuentra lo que busca:
        else:
            print(f"{busqueda}: no se encuentra en el inventario.")
    # si ingresa a la opcion 2 del menu:
    elif select == "2":
        print(" ingresaste a: actualizacion de stock")
        # se le solicita al usuario el articulo a actualizar:
        Actualizar_Articulo = input(
            "ingresa el articulo a actualizar: ").title().replace(" ", "")
        # se valida el ingreso:
        while Actualizar_Articulo.isalnum() == False:
            Actualizar_Articulo = input(
                "Error: no puedes ingresar caracteres especiales.\n ingresa el articulo a actualizar: ").title().replace(" ", "")
        # en caso de que se encuentre el articulo:
        if Actualizar_Articulo in stock:
            # mostramos la cantidad actual:
            print(f"""
                stock actual del articulo en sistema: 
                {Actualizar_Articulo}:{stock[Actualizar_Articulo]}""")
            # solicitamos el stock para sumarlo al existente:
            Actualizar_Stock = input(
                "ingresa la cantidad a sumar al stock actual: ").replace(" ", "")
            # validamos el ingreso:
            while Actualizar_Stock.isdigit() == False:
                Actualizar_Stock = input(
                    "Error: solo puedes ingresar numeros.\n Cantidad a sumar: ").replace(" ", "")
            # pasamos la variable de str a int:
            Actualizar_Stock = int(Actualizar_Stock)
            # sumamos los valores:
            Actualizar_Stock += stock[Actualizar_Articulo]
            # ingresamos el valor actual:
            stock[Actualizar_Articulo] = Actualizar_Stock
        # en caso de que no se encuentre el articulo:
        else:
            print(f"{Actualizar_Articulo}: no se encuentra en el inventario.\n puedes ingresarlo utilizando la opcion 3 del menu\n")
    # en caso de que el usuario ingrese a la opcion 3:
    elif select == "3":
        print("ingreso a: agregar articulo.")
        # solicitamos el nuevo articulo a ingresar en el diccionario:
        nuevo_articulo = input("ingresa el articulo:").title().replace(" ", "")
        # validamos el ingreso:
        while nuevo_articulo.isalnum() == False:
            nuevo_articulo = input(
                "Error:no puedes ingresar caracteres especiales.\n\n ingresa el nuevo articulo: ").title().replace(" ", "")
        # solicitamos la cantidad de existencias del articulo:
        articulo_stock = input(
            f"ingresa la cantidad de {nuevo_articulo}: ").replace(" ", "")
        # validamos el ingreso :
        while articulo_stock.isdigit() == False:
            articulo_stock = input(
                f"Error: solo puedes ingresar numeros.\n ingresa la cantidad de {nuevo_articulo}: ").replace(" ", "")
        # pasamos el ingreso de str a int
        articulo_stock = int(articulo_stock)
        # ingresamos el articulo y su stock al diccionario:
        stock[nuevo_articulo] = articulo_stock
    # si en la seleccion de menu ingresa un dato no valido:
    else:
        print("Error: ingreso no valido")
