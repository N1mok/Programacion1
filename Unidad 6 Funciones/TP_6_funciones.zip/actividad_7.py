## ---- Actividad 7 ----##
# definimos la funcion
def operaciones_basicas(a, b):
    # dentro de la funcion se realizan las operaciones:
    suma = a + b
    if a > b:
        division = a/b
        resta = a-b
    else:
        division = b/a
        resta = b-a
    multiplicacion = a*b
    return suma, resta, division, multiplicacion


# solicitamos los datos al operador para utilizarlos en la funcion:
print("ingresa 2 numeros diferentes para darte los resultados de:\n   *suma\n   *resta\n   *division\n   *multiplicacion.")
# primer numero:
a = input("ingresa el primer numero: ").replace(" ", "")
# validamos el ingreso del primer numero:
while a.isdigit() == False:
    a = input("Error: debes ingresar un numero\n ingresa el primer numero: ").replace(
        " ", "")
# pasamos el str a int:
a = int(a)
# segundo numero:
b = input("ingresa el segundo numero: ").replace(" ", "")
# validamos el ingreso del segundo numero:
while b.isdigit() == False:
    b = input = (
        "Error: debes ingresar un numero\ ingresa el segundo numero: ").replace(" ", "")
# pasamos el str a int:
b = int(b)
# solicitamos a la funcion los resultados guardados en forma de tupla:
suma, resta, division, multiplicacion = operaciones_basicas(a, b)
print(f"el resultado de la suma es: {suma}")
print(f"el resultado de la resta: {resta}")
print(f"el resultado de la division: {division}")
print(f"el resultado de la multiplicacion: {multiplicacion}")
