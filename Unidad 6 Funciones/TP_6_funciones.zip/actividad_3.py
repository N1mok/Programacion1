## ---- Actividad 3 ----##
# primero definimos la funcion con los parametros que vamos a utilizar:
def informacion_personal(nombre, apellido, edad, residencia):
    # una vez que el usuario ingrese los datos la funcion imprime:
    print(f"Soy {nombre} {apellido}, tengo {edad} años y vivo en: {residencia}")


# se solicitan los datos al usuario y se validan mediante bucle while:
nombre = input("ingresa tu nombre: ").title().replace(" ", "")
while nombre.isalpha() == False:
    nombre = input("Error: solo puedes ingresar letras. \n ingresa tu nombre: ").title(
    ).replace(" ", "")
apellido = input("ingresa tu apellido: ").title().replace(" ", "")
while apellido.isalpha() == False:
    apellido = input(
        "Error: solo puedes ingresar letras. \n ingresa tu apellido: ").title().replace(" ", "")
residencia = input("ingresa donde vives: ").title().replace(" ", "")
while residencia.isalpha() == False:
    residencia = input(
        "Error: solo puedes ingresar letras. \n ingresa donde vives: ").title().replace(" ", "")
edad = input("ingresa tu edad: ").replace(" ", "")
while edad.isdigit() == False:
    edad = input(
        "Error: solo puedes ingresar numeros.\n ingresa tu edad: ").replace(" ", "")
# se ejecuta la funcion:
informacion_personal(nombre, apellido, edad, residencia)
