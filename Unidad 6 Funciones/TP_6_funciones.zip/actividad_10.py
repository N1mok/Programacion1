## ---- Actividad 10 ----##
# definimos la variable segun lo solicitado:
def calcular_promedio(a, b, c):
    promedio = (a+b+c)/3
    return promedio


# pedimos al usuario los datos necesarios para obtener el promedio:
print("a continuacion te solicitamos 3 numeros para sacar el promedio:")
a = input("primer numero: ").replace(" ", "")
while a.isdigit() == False:
    a = input("Error: ingresa un numero.\n primer numero: ").replace(" ", "")
a = int(a)
b = input("segundo numero: ").replace(" ", "")
while b.isdigit() == False:
    b = input("Error: ingresa un numero.\n segundo numero: ").replace(" ", "")
b = int(b)
c = input("tercer numero: ").replace(" ", "")
while c.isdigit() == False:
    c = input("Error: ingresa un numero.\n tercer numero: ").replace(" ", "")
c = int(c)
promedio = calcular_promedio(a, b, c)
print(f"el promedio de {a}, {b} y {c} es de: {promedio}")
