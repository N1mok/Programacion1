## ---- Actividad 1 ----##
# Se define la funcion con lo solicitado:
def imprimir_hola_mundo():
    print("Hola Mundo!")


# utilizamos la funcion para imprimir el mensaje en pantalla:
imprimir_hola_mundo()
