## ---- Actividad 8 ----##
# definimos la funcion como fue solicitado:
def calcular_imc(peso, altura):
    # dentro de la funcion realizamos el calculo:
    imc = peso/altura**2
    # definimos los rangos segun la OMS:
    if imc < 1.85:
        resImc = "infrapeso/bajo peso."
    elif imc <= 24.9:
        resImc = "peso normal."
    elif imc <= 29.9:
        resImc = "sobre peso."
    elif imc > 30:
        resImc = "obesidad."
    return imc, resImc


print("a continuacion le pediremos su peso y altura: ")
# solicitamos al operador los datos necesarios:
# primero el peso:
peso = input("ingrese su peso: ").replace(" ", "")
# validamos:
while peso.isdigit() == False:
    peso = input(
        "Error: Solo puede ingresar numeros.\n ingrese su peso: ").replace(" ", "")
# pasamos la variable de str a int:
peso = int(peso)
# solicitamos la altura:
altura = input("ingrese su altura: ")
# nos aseguramos de que sea un numero flotante:
while True:
    numAltura = altura.replace(".", "")
    if numAltura.isdigit() == True:
        break
    # en caso de que haya ingresado algun caracter no valido:
    elif numAltura.isdigit() == False:
        altura = input(
            "error: ingresa tu altura de la siguiente forma: 1.70\n  Altura: ")
# pasamos la variable altura de str a float:
altura = float(altura)
# le damos los valores a la funcion y solicitamos los resultados:
imc, resImc = calcular_imc(peso, altura)
print(f"""segun la OMS mediante el indice de masa corporal entre los 20 y los 60 años:
tu Indice de masa corporal es de: {imc:.2f} y su clasificacion es de: {resImc}""")
