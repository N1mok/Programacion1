## ---- Actividad 2 ----##
# se define la funcion con los parametros que ingresara el usuario:
def saludar_usuario(nombre):
    # una vez que recibe el nombre del usuario:
    print(f"hola {nombre}!")


# se solicitan los datos al usuario para utilizarlos en la funcion:
nombre = input("por favor ingresa tu nombre: ")
# se ejecuta la funcion:
saludar_usuario(nombre)
