## ---- Actividad 4 ----##
# en este ejercicio se utilizara el mismo parametro para las dos funciones:
def calcular_area_circulo(radio):
    area = print(f"el area del circulo es de: {radio**2*3.1416:.2f}")
    return area

# se repite el parametro:


def calcular_perimetro_circulo(radio):
    perimetro = print(f"el perimetro del circulo es de: {2*3.1416*radio:.2f}")
    return perimetro


# solicitamos el dato al usuario para utilizarlo en la funcion:
radio = input("ingresa el radio del circulo a examinar: ").replace(" ", "")
# validamos el ingreso:
while radio.isdigit() == False:
    radio = input(
        "Error: solo puedes ingresar numeros\n radio del circulo: ").replace(" ", "")
# pasamos la variable de str a int:
radio = int(radio)
calcular_area_circulo(radio)
calcular_perimetro_circulo(radio)
