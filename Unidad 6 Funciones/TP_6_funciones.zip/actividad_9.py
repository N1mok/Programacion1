## ---- Actividad 9 ----##
# definimos la funcion como fue solicitado:
def celsius_a_fahrenheit(celsius):
    # realizamos la operacion para transformar celsius a fahrenheit:
    fahrenheit = (celsius * 9/5) + 32
    return fahrenheit


# solicitamos al usuario que ingrese la temperatura en celsius:
celsius = input(
    "por favor ingresa los grados celsius a transformar en fahrenheit\n grados celsius: ").replace(" ", "")
while celsius == False:
    celsius = input(
        "Error: solo puedes ingresar numeros, si quieres ingresar 30 grados celsius solo ingresa el numero.\n grados celsius: ").replace(" ", "")
celsius = int(celsius)
# solicitamos el resultado a la funcion
fahrenheit = celsius_a_fahrenheit(celsius)
print(f"""ingresaste: 
    {celsius} grados celsius
equivalen a:
    {fahrenheit} grados fahrenheit""")
