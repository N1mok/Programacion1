
## ---- Actividad 6 ----##
# definimos la funcion y parametro:
def tabla_multiplicar(numero):
    for i in range(1, 11):
        print(f"{numero}x{i}={numero*i}")


# solicitamos al usuario el dato que necesitamos:
numero = input(
    "ingresa un numero para imprimir la tabla de multiplicar del mismo: ")
# validamos la entrada:
while numero.isdigit() == False:
    numero = input(
        "error: debes ingresar un numero entero positivo\n   numero: ")
numero = int(numero)
# ejecutamos la funcion:
tabla_multiplicar(numero)
