## ---- Actividad 5 ----##
# primero definimos funcion y parametros:
def segundos_a_horas(segundos):
    hora = print(f"ingresaste {segundos} equivalen a : {segundos/3600} horas")
    return hora


# solicitamos al usuario que ingrese el dato a examinar:
segundos = input(
    "ingresa segundos para ver su equivalente en horas:").replace(" ", "")
# validamos el ingreso:
while segundos.isdigit() == False:
    segundos = input(
        "Error: por favor ingresa numeros\n segundos: ").replace(" ", "")
# convertimos de str a int:
segundos = int(segundos)
# ejecutamos la funcion:
segundos_a_horas(segundos)
